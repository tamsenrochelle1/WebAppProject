<?php
$hn = "localhost"; //host name
$db = "LibraryDB"; //database
$un = "root"; //username
$pw = "root"; //password -- I'm on a Mac so it is also root

?>
