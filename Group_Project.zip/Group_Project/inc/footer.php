
    <!-- Footer -->
    <footer class="navbar navbar-dark bg-dark">
        <img src="images\logo.png" width="30" height="30">
	</footer>

</body>
</html>
